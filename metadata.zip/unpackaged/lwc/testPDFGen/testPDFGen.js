import { LightningElement, api } from 'lwc';
import generatePDF from '@salesforce/apex/pdfController.generatePDF'
export default class TestPDFGen extends LightningElement {

    @api recordId;
    total;
    imageUrl = 'https://www.sparksuite.com/images/logo.png'


    invoiceData = {
        invoiceNo: '123',
        invoiceCreated: 'January 10, 2022',
        companyName: 'Sparksuit ,Inc',
        address1: '12345 sunny road',
        address2: 'sunny villa , CA 12345'
    }


    clientData = {
        client: 'Acne Corp',
        userName: 'John Doe',
        email: 'john@example.com'
    }


    sercives = [
        { name: 'consultant Fee', amount: 1000.00 },
        { name: 'WebSite Design', amount: 300.00 },
        { name: 'Hosting(3 months)', amount: 75.00 }

    ]


    get totalAmount() {
        return this.sercives.reduce((total, service) => {


            return total = total + service.amount
        }, 0)
    }



    pdfHandler() {
        let content = this.template.querySelector(".container")
        console.log(content.outerHTML)


        generatePDF({ recordId: this.recordId, htmlData: content.outerHTML }).then(result => {
            console.log('attachment id : ', result)
            window.open('https://binarymenance9-dev-ed.develop.my.salesforce.com/sfc/servlet.shepherd/document/download/' + result + '?operationContext=S1')




        })

    }

}
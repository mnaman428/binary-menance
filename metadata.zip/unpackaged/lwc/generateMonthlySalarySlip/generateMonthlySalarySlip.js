import { LightningElement, api, wire } from 'lwc';
import binanryImg from "@salesforce/resourceUrl/binanryMenance";
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import MONTH from '@salesforce/schema/Pay_Slips__c.Month__c';
import YEAR from '@salesforce/schema/Pay_Slips__c.Year__c';
import DAYS_IN_MONTH from '@salesforce/schema/Pay_Slips__c.Days_in_month__c';
import EFFECTIVE_WORKING_DAYS from '@salesforce/schema/Pay_Slips__c.Effective_Working_Days__c';
import BASIC from '@salesforce/schema/Pay_Slips__c.Basic_Salary__c';
import HRA from '@salesforce/schema/Pay_Slips__c.HRA__c';
import CONVEYANCE from '@salesforce/schema/Pay_Slips__c.Conveyance__c';
import MEDICAL_ALLOWANCE from '@salesforce/schema/Pay_Slips__c.Medical_Allowance__c';
import SPECIAL_ALLOWANCE from '@salesforce/schema/Pay_Slips__c.Special_Allowance__c';
import EMPLOYEENAME from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.Name';
import DESIGNATION from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.Designation__c';
import EMPLOYEE_ID from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.Employee_Id__c';
import ESINO from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.ESI_NO__c';
import PAN_NO from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.PAN_NO__c';
import BANK_AC_NO from '@salesforce/schema/Pay_Slips__c.Employee_Informations__r.Bank_Account_No__c';
import ADDRESS from '@salesforce/schema/Binary__c.Address__c';
import ADDRESS_1 from '@salesforce/schema/Binary__c.Address1__c';
import EMAIL from '@salesforce/schema/Binary__c.Email__c';
import WEBSITE from '@salesforce/schema/Binary__c.Website__c';
import PHONENO from '@salesforce/schema/Binary__c.phoneNo__c';
import generatePDF from '@salesforce/apex/pdfController.generatePDF'


const METADATA_FIELDS = [
    'Binary__mdt.Address__c',
    'Binary__mdt.Address1__c',
    'Binary__mdt.Email__c',
    'Binary__mdt.phoneNo__c',
    'Binary__mdt.Website__c'
];


const FIELDS = [MONTH, YEAR, DAYS_IN_MONTH, DAYS_IN_MONTH, EFFECTIVE_WORKING_DAYS, BASIC, HRA, CONVEYANCE, MEDICAL_ALLOWANCE, SPECIAL_ALLOWANCE,
    EMPLOYEENAME, DESIGNATION, EMPLOYEE_ID, ESINO, PAN_NO, BANK_AC_NO]

export default class GenerateMonthlySalarySlip extends LightningElement {


    imageData = binanryImg;
    @api recordId;
    showSpiner = false;
    jsPdfInitialized = false;
    metadataRecordid = 'm005g000002DUARAA4';
    downloadPaySlip = false;
    address;
    address1;
    email;
    web;
    phoneNo;
    month;
    year;
    employeeName;
    employeeid;
    designation;
    month;
    year;

    /*@wire(getRecord, { recordId: '$metadataRecordid', fields: METADATA_FIELDS })
    metadatarecord({ data, error }) {
        console.log('data metadata' + JSON.stringify(data))
        this.address = getFieldValue(data, ADDRESS);
        this.address1 = getFieldValue(data, ADDRESS_1);
        this.email = getFieldValue(data, EMAIL);
        this.web = getFieldValue(data, WEBSITE);
        this.phoneNo = getFieldValue(data, PHONENO);
    }*/

    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    salaryInfo({ data, error }) {
        if (data) {
            this.month = getFieldValue(data, MONTH);
            this.year = getFieldValue(data, YEAR);
            this.employeeName = getFieldValue(data, EMPLOYEENAME);
            this.employeeid = getFieldValue(data, EMPLOYEE_ID);
            this.designation = getFieldValue(data, DESIGNATION);
        }
        else if (error) {
            this.error = error;
        }
    }


    
    generatePdf() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.addImage(imgData, 'jpeg', 150, 25, 45, 30);
        doc.setFontSize(20);
        doc.setFont('helvetica')
        doc.text("INVOICE", 90, 20)
        doc.setFontSize(10)
        doc.setFont('arial black')
        doc.text("Account Name:", 20, 40)
        doc.text("Contact Name:", 20, 50)
        doc.text("Phone Number:", 20, 60)
        doc.text("Email:", 20, 70)
        doc.text("Billing Address:", 20, 80)
        doc.text("Shipping Address:", 150, 80)
        doc.setFontSize(10)
        doc.setFont('times')
        /*doc.text(this.accountName, 45, 40)
        doc.text(this.phone, 45, 60)
        doc.text(this.name, 45, 50)
        doc.text(this.billTo, 20, 85)
        doc.text(this.shipTo, 150, 85)
        doc.text(this.email, 45, 70)*/
        doc.save("CustomerInvoice.pdf")

    }
    generateData() {
        this.downloadPaySlip = true;
        //this.showSpiner = true;
        this.generatePdf();
    }

    pdfHandler() {
        let content = this.template.querySelector(".container")
        console.log(content.outerHTML)


        generatePDF({ recordId: this.recordId, htmlData: content.outerHTML, pdfName: 'PAYSLIP '+ this.month + ' '+this.year }).then(result => {
            console.log('attachment id : ', result)
            window.open('https://binarymenance9-dev-ed.develop.my.salesforce.com/sfc/servlet.shepherd/document/download/' + result + '?operationContext=S1');

        })

    }

}
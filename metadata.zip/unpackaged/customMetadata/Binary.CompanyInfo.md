<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CompanyInfo</label>
    <protected>false</protected>
    <values>
        <field>Address1__c</field>
        <value xsi:type="xsd:string">Delhi, IN - 110085</value>
    </values>
    <values>
        <field>Address__c</field>
        <value xsi:type="xsd:string">179/2, Pocket 7, Sector 24, Rohini</value>
    </values>
    <values>
        <field>Email__c</field>
        <value xsi:type="xsd:string">info@binarymenance.com</value>
    </values>
    <values>
        <field>Website__c</field>
        <value xsi:type="xsd:string">https://binarymenance.com/</value>
    </values>
    <values>
        <field>phoneNo__c</field>
        <value xsi:type="xsd:string">+91 9996348508</value>
    </values>
</CustomMetadata>
